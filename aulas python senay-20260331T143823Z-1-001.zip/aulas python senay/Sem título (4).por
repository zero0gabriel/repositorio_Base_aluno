programa {
  funcao inicio() {
    inteiro a,b

    escreva("digite um valor para A:")
    leia(a)

    escreva("digite um valor para b:")
    leia(b)

    escreva("comparacoes: \n")
    escreva("a > b = " , a > b, "\n")
    escreva("a < b = " , a < b, "\n")
    escreva("a != b = " , a != b, "\n")
    escreva("a == b = " , a == b, "\n")
  }
}
